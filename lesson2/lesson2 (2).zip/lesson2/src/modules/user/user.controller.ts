import {
  Controller,
  Param,
  Get,
  Post,
  Body,
  UsePipes,
  ValidationPipe,
  UseGuards,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiParam,
  ApiBody,
} from '@nestjs/swagger';
import { UserService } from './user.service';
import { CreateUserDto } from './dto/create-user.dto';
import { validate } from 'class-validator';
import { CustomBody } from '../../decorators/body.decorator';
import { TestGuard } from '../../guards/test.guard';

function CustomMethodDecorator() {
  return function (
    target: any,
    propertyKey: string,
    descriptor: PropertyDescriptor,
  ) {
    const originalMethod = descriptor.value;

    descriptor.value = async function (...args: any[]) {
      const paramTypes = Reflect.getMetadata(
        'design:paramtypes',
        target,
        propertyKey,
      );

      if (paramTypes) {
        for (let i = 0; i < paramTypes.length; i++) {
          const ParamClass = paramTypes[i];
          const arg = args[i];

          if (
            ParamClass &&
            typeof ParamClass === 'function' &&
            ParamClass !== String &&
            ParamClass !== Number &&
            ParamClass !== Boolean
          ) {
            const dtoInstance = Object.assign(new ParamClass(), arg);
            const errors = await validate(dtoInstance);

            if (errors.length > 0) {
              throw new Error(
                `Validation failed: ${errors
                  .map((e) => Object.values(e.constraints || {}))
                  .flat()
                  .join(', ')}`,
              );
            }
          }
        }
      }

      return originalMethod.apply(this, args);
    };

    return descriptor;
  };
}

@ApiTags('users v1')
@Controller({ path: 'user', version: '1' })
export class UserController {
  constructor(private readonly userService: UserService) {}

  @UseGuards(TestGuard)
  @Get('/:limit')
  @ApiOperation({ summary: 'Get users list' })
  @ApiParam({
    name: 'limit',
    type: Number,
    description: 'Maximum number of users to return',
    required: true,
    example: 10,
  })
  @ApiResponse({
    status: 200,
    description: 'List of users returned successfully',
    type: CreateUserDto,
    isArray: true,
  })
  getAll(@Param('limit') limit: number) {
    return this.userService.getAll(limit);
  }

  @Post()
  @ApiOperation({ summary: 'Create a new user' })
  @ApiBody({ type: CreateUserDto })
  @ApiResponse({
    status: 201,
    description: 'User created',
    type: CreateUserDto,
  })
  @ApiResponse({ status: 400, description: 'Validation failed' })
  createUser(@Body() body: CreateUserDto) {
    return this.userService.addUser(body);
  }
}
